package com.bintina.mynews.search.api

interface ApiClient {

}