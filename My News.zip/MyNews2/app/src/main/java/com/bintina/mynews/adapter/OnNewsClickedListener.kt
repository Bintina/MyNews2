package com.bintina.mynews.adapter

interface OnNewsClickedListener {


    fun openLink(clickedNewsLink: String)
}